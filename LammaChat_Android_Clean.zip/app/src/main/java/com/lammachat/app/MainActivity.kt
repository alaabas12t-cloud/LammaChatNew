package com.lammachat.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "لَمّة شات"
            textSize = 32f
            setTextColor(Color.rgb(110, 60, 190))
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "تعارف • دردشة • ألعاب"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 35)
        }
        val phone = EditText(this).apply {
            hint = "رقم الهاتف"
            inputType = 2
        }
        val btn = Button(this).apply {
            text = "دخول / إنشاء حساب"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "سنضيف تسجيل الهاتف وFirebase في الخطوة التالية", Toast.LENGTH_LONG).show()
            }
        }
        val note = TextView(this).apply {
            text = "نسخة البداية جاهزة للتطوير. لا تعرض موقعك الدقيق."
            textSize = 14f
            setPadding(0, 30, 0, 0)
            gravity = Gravity.CENTER
        }

        box.addView(title)
        box.addView(sub)
        box.addView(phone, LinearLayout.LayoutParams(-1, -2))
        box.addView(btn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18 })
        box.addView(note)
        scroll.addView(box)
        setContentView(scroll)
    }
}
